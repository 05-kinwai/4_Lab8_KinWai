﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{
    public Text DebugText;
    public InputField txtAmount;
    float SGDAmount;
    public Toggle USD;
    public Toggle JPY;

    float value;
    public Text Convertedvalue;
    float valueamount;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void conversion()
    {
        SGDAmount = float.Parse(txtAmount.text);

        if (USD.GetComponent<Toggle>().gameObject == true)
        {
            value = SGDAmount * 0.74f;
            Convertedvalue.text = value.ToString() + " USD";
        }

        if (JPY.GetComponent<Toggle>().isOn == true)
        {
            value = SGDAmount * 110.5f;
            Convertedvalue.text = value.ToString() + " JPY";
        }

        if ((USD.GetComponent<Toggle>().gameObject == true) && (JPY.GetComponent<Toggle>().isOn == true))
        {
            Convertedvalue.text = "Invalid Input";
        }
       
    }
    public void clear()
    {
        Convertedvalue.text = "";
        txtAmount.text = "";
        JPY.GetComponent<Toggle>().isOn = false;
        USD.GetComponent<Toggle>().isOn = false;
    }
    
}
